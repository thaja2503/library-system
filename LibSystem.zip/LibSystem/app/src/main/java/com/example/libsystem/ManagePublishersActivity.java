package com.example.libsystem;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;

        import androidx.appcompat.app.AppCompatActivity;

public class ManagePublishersActivity extends AppCompatActivity {
    private EditText etPublisherName;
    private EditText etPublisherAddress;
    private EditText etPublisherPhone;
    private Button btnInsertPublisher;
    private Button btnUpdatePublisher;
    private Button btnDeletePublisher;
    private Button btnViewPublishers;
    private ListView lvPublishers;
    private PublisherDAO publisherDAO;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_publishers);


        etPublisherName = findViewById(R.id.et_publisher_name);
        etPublisherAddress = findViewById(R.id.et_publisher_address);
        etPublisherPhone = findViewById(R.id.et_publisher_phone);
        btnInsertPublisher = findViewById(R.id.btn_insert_publisher);
        btnUpdatePublisher = findViewById(R.id.btn_update_publisher);
        btnDeletePublisher = findViewById(R.id.btn_delete_publisher);
        btnViewPublishers = findViewById(R.id.btn_view_publishers);
        lvPublishers = findViewById(R.id.lv_publishers);


        publisherDAO = new PublisherDAO(this);


        btnInsertPublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertPublisher();
            }
        });

        btnUpdatePublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePublisher();
            }
        });

        btnDeletePublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deletePublisher();
            }
        });

        btnViewPublishers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPublishers();
            }
        });
    }

    private void insertPublisher() {
        String name = etPublisherName.getText().toString();
        String address = etPublisherAddress.getText().toString();
        String phone = etPublisherPhone.getText().toString();

        if (name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        long result = publisherDAO.insertPublisher(name, address, phone);
        if (result != -1) {
            Toast.makeText(this, "Publisher inserted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error inserting publisher", Toast.LENGTH_SHORT).show();
        }
    }

    private void updatePublisher() {
        String name = etPublisherName.getText().toString();
        String address = etPublisherAddress.getText().toString();
        String phone = etPublisherPhone.getText().toString();

        if (name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = publisherDAO.updatePublisher(name, address, phone);
        if (result > 0) {
            Toast.makeText(this, "Publisher updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error updating publisher", Toast.LENGTH_SHORT).show();
        }
    }

    private void deletePublisher() {
        String name = etPublisherName.getText().toString();

        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter Publisher Name", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = publisherDAO.deletePublisher(name);
        if (result > 0) {
            Toast.makeText(this, "Publisher deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error deleting publisher", Toast.LENGTH_SHORT).show();
        }
    }

    private void viewPublishers() {

        Toast.makeText(this, "View Publishers are implemented in database", Toast.LENGTH_SHORT).show();
    }
}