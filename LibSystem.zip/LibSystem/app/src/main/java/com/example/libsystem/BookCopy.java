package com.example.libsystem;


public class BookCopy {
    private String bookId;
    private String branchId;
    private String accessNo;

    public BookCopy(String bookId, String branchId, String accessNo) {
        this.bookId = bookId;
        this.branchId = branchId;
        this.accessNo = accessNo;
    }


    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBranchId() {
        return branchId;
    }

    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    public String getAccessNo() {
        return accessNo;
    }

    public void setAccessNo(String accessNo) {
        this.accessNo = accessNo;
    }
}