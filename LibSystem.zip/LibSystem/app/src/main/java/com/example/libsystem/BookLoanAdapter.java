package com.example.libsystem;

        import android.content.Context;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ArrayAdapter;
        import android.widget.TextView;

        import java.util.List;

public class BookLoanAdapter extends ArrayAdapter<BookLoan> {
    private LayoutInflater inflater;
    private int resource;

    public BookLoanAdapter(Context context, int resource, List<BookLoan> bookLoans) {
        super(context, resource, bookLoans);
        this.inflater = LayoutInflater.from(context);
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(resource, parent, false); // Inflate the correct resource
        }


        BookLoan bookLoan = getItem(position);


        TextView textViewAccessNo = convertView.findViewById(R.id.textViewAccessNo);
        TextView textViewBranchId = convertView.findViewById(R.id.textViewBranchId);
        TextView textViewCardNo = convertView.findViewById(R.id.textViewCardNo);
        TextView textViewDateOut = convertView.findViewById(R.id.textViewDateOut);
        TextView textViewDateDue = convertView.findViewById(R.id.textViewDateDue);

        if (bookLoan != null) {
            textViewAccessNo.setText(bookLoan.getAccessNo());
            textViewBranchId.setText(bookLoan.getBranchId());
            textViewCardNo.setText(bookLoan.getCardNo());
            textViewDateOut.setText(bookLoan.getDateOut());
            textViewDateDue.setText(bookLoan.getDateDue());
        }

        return convertView;
    }
}