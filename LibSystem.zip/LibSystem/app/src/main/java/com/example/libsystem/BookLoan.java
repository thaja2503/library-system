package com.example.libsystem;

public class BookLoan {
    private String accessNo;
    private String branchId;
    private String cardNo;
    private String dateOut;
    private String dateDue;
    private String dateReturned;

    public BookLoan(String accessNo, String branchId, String cardNo,
                    String dateOut, String dateDue, String dateReturned) {
        this.accessNo = accessNo;
        this.branchId = branchId;
        this.cardNo = cardNo;
        this.dateOut = dateOut;
        this.dateDue = dateDue;
        this.dateReturned = dateReturned;
    }


    public String getAccessNo() {
        return accessNo;
    }

    public void setAccessNo(String accessNo) {
        this.accessNo = accessNo;
    }

    public String getBranchId() {
        return branchId;
    }

    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getDateOut() {
        return dateOut;
    }

    public void setDateOut(String dateOut) {
        this.dateOut = dateOut;
    }

    public String getDateDue() {
        return dateDue;
    }

    public void setDateDue(String dateDue) {
        this.dateDue = dateDue;
    }

    public String getDateReturned() {
        return dateReturned;
    }

    public void setDateReturned(String dateReturned) {
        this.dateReturned = dateReturned;
    }
}