package com.example.libsystem;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;
        import androidx.appcompat.app.AppCompatActivity;

public class ManageBooksActivity extends AppCompatActivity {
    private EditText etBookId;
    private EditText etTitle;
    private EditText etPublisherName;
    private Button btnInsertBook;
    private Button btnUpdateBook;
    private Button btnDeleteBook;
    private Button btnViewBooks;
    private ListView lvBooks;
    private BookDAO bookDAO;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_books);


        etBookId = findViewById(R.id.et_book_id);
        etTitle = findViewById(R.id.et_title);
        etPublisherName = findViewById(R.id.et_publisher_name);
        btnInsertBook = findViewById(R.id.btn_insert_book);
        btnUpdateBook = findViewById(R.id.btn_update_book);
        btnDeleteBook = findViewById(R.id.btn_delete_book);
        btnViewBooks = findViewById(R.id.btn_view_books);
        lvBooks = findViewById(R.id.lv_books);


        bookDAO = new BookDAO(this);


        btnInsertBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertBook();
            }
        });

        btnUpdateBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBook();
            }
        });

        btnDeleteBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteBook();
            }
        });

        btnViewBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewBooks();
            }
        });
    }

    private void insertBook() {
        String bookId = etBookId.getText().toString();
        String title = etTitle.getText().toString();
        String publisherName = etPublisherName.getText().toString();

        if (bookId.isEmpty() || title.isEmpty() || publisherName.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        long result = bookDAO.insertBook(bookId, title, publisherName);
        if (result != -1) {
            Toast.makeText(this, "Book inserted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error inserting book", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateBook() {
        String bookId = etBookId.getText().toString();
        String title = etTitle.getText().toString();
        String publisherName = etPublisherName.getText().toString();

        if (bookId.isEmpty() || title.isEmpty() || publisherName.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = bookDAO.updateBook(bookId, title, publisherName);
        if (result > 0) {
            Toast.makeText(this, "Book updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error updating book", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteBook() {
        String bookId = etBookId.getText().toString();

        if (bookId.isEmpty()) {
            Toast.makeText(this, "Please enter Book ID", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = bookDAO.deleteBook(bookId);
        if (result > 0) {
            Toast.makeText(this, "Book deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error deleting book", Toast.LENGTH_SHORT).show();
        }
    }

    private void viewBooks() {

        Toast.makeText(this, "View books functionality are implemented in database", Toast.LENGTH_SHORT).show();
    }
}
