package com.example.libsystem;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;
        import androidx.appcompat.app.AppCompatActivity;

public class ManageMembersActivity extends AppCompatActivity {
    private EditText etCardNo;
    private EditText etMemberName;
    private EditText etMemberAddress;
    private EditText etMemberPhone;
    private EditText etUnpaidDues;
    private Button btnInsertMember;
    private Button btnUpdateMember;
    private Button btnDeleteMember;
    private Button btnViewMembers;
    private ListView lvMembers;
    private MemberDAO memberDAO;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_members);


        etCardNo = findViewById(R.id.et_card_no);
        etMemberName = findViewById(R.id.et_member_name);
        etMemberAddress = findViewById(R.id.et_member_address);
        etMemberPhone = findViewById(R.id.et_member_phone);
        etUnpaidDues = findViewById(R.id.et_unpaid_dues);
        btnInsertMember = findViewById(R.id.btn_insert_member);
        btnUpdateMember = findViewById(R.id.btn_update_member);
        btnDeleteMember = findViewById(R.id.btn_delete_member);
        btnViewMembers = findViewById(R.id.btn_view_members);
        lvMembers = findViewById(R.id.lv_members);


        memberDAO = new MemberDAO(this);


        btnInsertMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertMember();
            }
        });

        btnUpdateMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateMember();
            }
        });

        btnDeleteMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteMember();
            }
        });

        btnViewMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewMembers();
            }
        });
    }

    private void insertMember() {
        String cardNo = etCardNo.getText().toString();
        String name = etMemberName.getText().toString();
        String address = etMemberAddress.getText().toString();
        String phone = etMemberPhone.getText().toString();
        double unpaidDues;

        try {
            unpaidDues = Double.parseDouble(etUnpaidDues.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Unpaid Dues", Toast.LENGTH_SHORT).show();
            return;
        }

        if (cardNo.isEmpty() || name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        long result = memberDAO.insertMember(cardNo, name, address, phone, unpaidDues);
        if (result != -1) {
            Toast.makeText(this, "Member inserted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error inserting member", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateMember() {
        String cardNo = etCardNo.getText().toString();
        String name = etMemberName.getText().toString();
        String address = etMemberAddress.getText().toString();
        String phone = etMemberPhone.getText().toString();
        double unpaidDues;

        try {
            unpaidDues = Double.parseDouble(etUnpaidDues.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Unpaid Dues", Toast.LENGTH_SHORT).show();
            return;
        }

        if (cardNo.isEmpty() || name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = memberDAO.updateMember(cardNo, name, address, phone, unpaidDues);
        if (result > 0) {
            Toast.makeText(this, "Member updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error updating member", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteMember() {
        String cardNo = etCardNo.getText().toString();

        if (cardNo.isEmpty()) {
            Toast.makeText(this, "Please enter Card Number", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = memberDAO.deleteMember(cardNo);
        if (result > 0) {
            Toast.makeText(this, "Member deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error deleting member", Toast.LENGTH_SHORT).show();
        }
    }

    private void viewMembers() {

        Toast.makeText(this, "View Members are implemented in database", Toast.LENGTH_SHORT).show();
    }
}