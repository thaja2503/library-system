package com.example.libsystem;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookAuthorDAO {
    private SQLiteDatabase db;

    public BookAuthorDAO(Context context) {
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertBookAuthor(String bookId, String authorName) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("AUTHOR_NAME", authorName);
        return db.insert("Book_Author", null, values);
    }

    public int updateBookAuthor(String bookId, String authorName) {
        ContentValues values = new ContentValues();
        values.put("AUTHOR_NAME", authorName);
        return db.update("Book_Author", values, "BOOK_ID = ?", new String[]{bookId});
    }

    public int deleteBookAuthor(String bookId, String authorName) {
        return db.delete("Book_Author", "BOOK_ID = ? AND AUTHOR_NAME = ?", new String[]{bookId, authorName});
    }

    public Cursor getBookAuthor(String bookId, String authorName) {
        return db.query("Book_Author", null, "BOOK_ID = ? AND AUTHOR_NAME = ?", new String[]{bookId, authorName}, null, null, null);
    }

    public Cursor getAllBookAuthors() {
        return db.query("Book_Author", null, null, null, null, null, "BOOK_ID ASC");
    }
}

