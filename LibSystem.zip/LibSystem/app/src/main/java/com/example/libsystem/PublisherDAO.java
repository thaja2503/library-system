package com.example.libsystem;


        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

public class PublisherDAO {
    private SQLiteDatabase db;

    public PublisherDAO(Context context) {
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertPublisher(String name, String address, String phone) {
        ContentValues values = new ContentValues();
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        return db.insert("Publisher", null, values);
    }

    public int updatePublisher(String name, String address, String phone) {
        ContentValues values = new ContentValues();
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        return db.update("Publisher", values, "NAME = ?", new String[]{name});
    }

    public int deletePublisher(String name) {
        return db.delete("Publisher", "NAME = ?", new String[]{name});
    }

    public Cursor getPublisher(String name) {
        return db.query("Publisher", null, "NAME = ?", new String[]{name}, null, null, null);
    }

    public Cursor getAllPublishers() {
        return db.query("Publisher", null, null, null, null, null, "NAME ASC");
    }
}


