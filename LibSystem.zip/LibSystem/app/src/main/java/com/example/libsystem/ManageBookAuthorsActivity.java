package com.example.libsystem;

        import android.content.DialogInterface;
        import android.os.Bundle;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

        import androidx.appcompat.app.AlertDialog;
        import androidx.appcompat.app.AppCompatActivity;

        import java.util.ArrayList;
        import java.util.List;

public class ManageBookAuthorsActivity extends AppCompatActivity {
    private ListView listViewBookAuthors;
    private List<BookAuthor> bookAuthorsList;
    private BookAuthorDAO bookAuthorDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book_authors);


        bookAuthorDAO = new BookAuthorDAO(this);
        bookAuthorsList = new ArrayList<>();
        listViewBookAuthors = findViewById(R.id.listViewBookAuthors);


        loadBookAuthors();


        Button btnAddBookAuthor = findViewById(R.id.btnAddBookAuthor);
        btnAddBookAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddBookAuthorDialog();
            }
        });
    }



    private void loadBookAuthors() {

        bookAuthorsList.clear();
        Cursor cursor = bookAuthorDAO.getAllBookAuthors();

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {

                        String bookId = cursor.getString(cursor.getColumnIndex("BOOK_ID"));
                        String authorName = cursor.getString(cursor.getColumnIndex("AUTHOR_NAME"));

                        bookAuthorsList.add(new BookAuthor(bookId, authorName));
                    } while (cursor.moveToNext());
                }
            } finally {

                cursor.close();
            }
        }


        BookAuthorAdapter bookAuthorAdapter = new BookAuthorAdapter(this, R.layout.item_book_author, bookAuthorsList);


        listViewBookAuthors.setAdapter(bookAuthorAdapter);
    }
    private void showAddBookAuthorDialog() {

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_book_author, null);
        dialogBuilder.setView(dialogView);

        final EditText editTextBookId = dialogView.findViewById(R.id.editTextBookId);
        final EditText editTextAuthorName = dialogView.findViewById(R.id.editTextAuthorName);

        dialogBuilder.setTitle("Add Book Author");
        dialogBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String bookId = editTextBookId.getText().toString().trim();
                String authorName = editTextAuthorName.getText().toString().trim();

                if (!bookId.isEmpty() && !authorName.isEmpty()) {
                    long result = bookAuthorDAO.insertBookAuthor(bookId, authorName);
                    if (result != -1) {
                        Toast.makeText(ManageBookAuthorsActivity.this, "Book Author added successfully", Toast.LENGTH_SHORT).show();
                        loadBookAuthors();
                    } else {
                        Toast.makeText(ManageBookAuthorsActivity.this, "Failed to add Book Author", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookAuthorsActivity.this, "Please enter Book ID and Author Name", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialogBuilder.setNegativeButton("Cancel", null);

        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

}