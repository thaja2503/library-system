package com.example.libsystem;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;
        import androidx.appcompat.app.AppCompatActivity;

public class ManageBranchesActivity extends AppCompatActivity {
    private EditText etBranchId;
    private EditText etBranchName;
    private EditText etBranchAddress;
    private Button btnInsertBranch;
    private Button btnUpdateBranch;
    private Button btnDeleteBranch;
    private Button btnViewBranches;
    private ListView lvBranches;
    private BranchDAO branchDAO;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_branches);


        etBranchId = findViewById(R.id.et_branch_id);
        etBranchName = findViewById(R.id.et_branch_name);
        etBranchAddress = findViewById(R.id.et_branch_address);
        btnInsertBranch = findViewById(R.id.btn_insert_branch);
        btnUpdateBranch = findViewById(R.id.btn_update_branch);
        btnDeleteBranch = findViewById(R.id.btn_delete_branch);
        btnViewBranches = findViewById(R.id.btn_view_branches);
        lvBranches = findViewById(R.id.lv_branches);


        branchDAO = new BranchDAO(this);


        btnInsertBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertBranch();
            }
        });

        btnUpdateBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBranch();
            }
        });

        btnDeleteBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteBranch();
            }
        });

        btnViewBranches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewBranches();
            }
        });
    }

    private void insertBranch() {
        String branchId = etBranchId.getText().toString();
        String branchName = etBranchName.getText().toString();
        String branchAddress = etBranchAddress.getText().toString();

        if (branchId.isEmpty() || branchName.isEmpty() || branchAddress.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        long result = branchDAO.insertBranch(branchId, branchName, branchAddress);
        if (result != -1) {
            Toast.makeText(this, "Branch inserted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error inserting branch", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateBranch() {
        String branchId = etBranchId.getText().toString();
        String branchName = etBranchName.getText().toString();
        String branchAddress = etBranchAddress.getText().toString();

        if (branchId.isEmpty() || branchName.isEmpty() || branchAddress.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = branchDAO.updateBranch(branchId, branchName, branchAddress);
        if (result > 0) {
            Toast.makeText(this, "Branch updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error updating branch", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteBranch() {
        String branchId = etBranchId.getText().toString();

        if (branchId.isEmpty()) {
            Toast.makeText(this, "Please enter Branch ID", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = branchDAO.deleteBranch(branchId);
        if (result > 0) {
            Toast.makeText(this, "Branch deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error deleting branch", Toast.LENGTH_SHORT).show();
        }
    }

    private void viewBranches() {

        Toast.makeText(this, "View Branches are implemented in database", Toast.LENGTH_SHORT).show();
    }
}
