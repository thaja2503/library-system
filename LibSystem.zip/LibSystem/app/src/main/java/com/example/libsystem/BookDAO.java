package com.example.libsystem;

        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

public class BookDAO {
    private SQLiteDatabase db;

    public BookDAO(Context context) {
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertBook(String bookId, String title, String publisherName) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("TITLE", title);
        values.put("PUBLISHER_NAME", publisherName);
        return db.insert("Book", null, values);
    }

    public int updateBook(String bookId, String title, String publisherName) {
        ContentValues values = new ContentValues();
        values.put("TITLE", title);
        values.put("PUBLISHER_NAME", publisherName);
        return db.update("Book", values, "BOOK_ID = ?", new String[]{bookId});
    }

    public int deleteBook(String bookId) {
        return db.delete("Book", "BOOK_ID = ?", new String[]{bookId});
    }

    public Cursor getBook(String bookId) {
        return db.query("Book", null, "BOOK_ID = ?", new String[]{bookId}, null, null, null);
    }

    public Cursor getAllBooks() {
        return db.query("Book", null, null, null, null, null, "TITLE ASC");
    }
}

