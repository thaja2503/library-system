package com.example.libsystem;


        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

public class MemberDAO {
    private SQLiteDatabase db;

    public MemberDAO(Context context) {
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertMember(String cardNo, String name, String address, String phone, double unpaidDues) {
        ContentValues values = new ContentValues();
        values.put("CARD_NO", cardNo);
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        values.put("UNPAID_DUES", unpaidDues);
        return db.insert("Member", null, values);
    }

    public int updateMember(String cardNo, String name, String address, String phone, double unpaidDues) {
        ContentValues values = new ContentValues();
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        values.put("UNPAID_DUES", unpaidDues);
        return db.update("Member", values, "CARD_NO = ?", new String[]{cardNo});
    }

    public int deleteMember(String cardNo) {
        return db.delete("Member", "CARD_NO = ?", new String[]{cardNo});
    }

    public Cursor getMember(String cardNo) {
        return db.query("Member", null, "CARD_NO = ?", new String[]{cardNo}, null, null, null);
    }

    public Cursor getAllMembers() {
        return db.query("Member", null, null, null, null, null, "NAME ASC");
    }
}
