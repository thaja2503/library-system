package com.example.libsystem;


        import android.content.DialogInterface;
        import android.os.Bundle;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

        import androidx.appcompat.app.AlertDialog;
        import androidx.appcompat.app.AppCompatActivity;

        import java.util.ArrayList;
        import java.util.List;

public class ManageBookLoansActivity extends AppCompatActivity {
    private ListView listViewBookLoans;
    private List<BookLoan> bookLoansList;
    private BookLoanDAO bookLoanDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book_loans);

        bookLoanDAO = new BookLoanDAO(this);
        bookLoansList = new ArrayList<>();
        listViewBookLoans = findViewById(R.id.listViewBookLoans);

        loadBookLoans();

        Button btnAddBookLoan = findViewById(R.id.btnAddBookLoan);
        btnAddBookLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddBookLoanDialog();
            }
        });
    }

    private void loadBookLoans() {
        bookLoansList.clear();
        Cursor cursor = bookLoanDAO.getAllBookLoans();

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        // Get book loan details from the cursor
                        String accessNo = cursor.getString(cursor.getColumnIndex("ACCESS_NO"));
                        String branchId = cursor.getString(cursor.getColumnIndex("BRANCH_ID"));
                        String cardNo = cursor.getString(cursor.getColumnIndex("CARD_NO"));
                        String dateOut = cursor.getString(cursor.getColumnIndex("DATE_OUT"));
                        String dateDue = cursor.getString(cursor.getColumnIndex("DATE_DUE"));
                        String dateReturned = cursor.getString(cursor.getColumnIndex("DATE_RETURNED"));

                        // Add to the list of book loans
                        bookLoansList.add(new BookLoan(accessNo, branchId, cardNo, dateOut, dateDue, dateReturned));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }


        BookLoanAdapter bookLoanAdapter = new BookLoanAdapter(this, R.layout.item_book_loan, bookLoansList);
        listViewBookLoans.setAdapter(bookLoanAdapter); // Set the adapter to the ListView
    }

    private void showAddBookLoanDialog() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_book_loan, null);
        dialogBuilder.setView(dialogView);


        final EditText editTextAccessNo = dialogView.findViewById(R.id.editTextAccessNo);
        final EditText editTextBranchId = dialogView.findViewById(R.id.editTextBranchId);
        final EditText editTextCardNo = dialogView.findViewById(R.id.editTextCardNo);
        final EditText editTextDateOut = dialogView.findViewById(R.id.editTextDateOut);
        final EditText editTextDateDue = dialogView.findViewById(R.id.editTextDateDue);

        dialogBuilder.setTitle("Add Book Loan");
        dialogBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                String accessNo = editTextAccessNo.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();
                String cardNo = editTextCardNo.getText().toString().trim();
                String dateOut = editTextDateOut.getText().toString().trim();
                String dateDue = editTextDateDue.getText().toString().trim();


                if (!accessNo.isEmpty() && !branchId.isEmpty() && !cardNo.isEmpty() && !dateOut.isEmpty() && !dateDue.isEmpty()) {
                    long result = bookLoanDAO.insertBookLoan(accessNo, branchId, cardNo, dateOut, dateDue, null); // Insert into the database
                    if (result != -1) {
                        Toast.makeText(ManageBookLoansActivity.this, "Book Loan added successfully", Toast.LENGTH_SHORT).show();
                        loadBookLoans();
                    } else {
                        Toast.makeText(ManageBookLoansActivity.this, "Failed to add Book Loan", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookLoansActivity.this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialogBuilder.setNegativeButton("Cancel", null);

        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }
}