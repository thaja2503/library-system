package com.example.libsystem;


        import java.util.List;
        import android.content.Context;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ArrayAdapter;
        import android.widget.TextView;



public class BookCopyAdapter extends ArrayAdapter<BookCopy> {
    private LayoutInflater inflater;
    private int resource;

    public BookCopyAdapter(Context context, int resource, List<BookCopy> bookCopies) {
        super(context, resource, bookCopies);
        this.resource = resource;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(resource, parent, false);
        }


        BookCopy bookCopy = getItem(position);


        TextView textViewBookId = convertView.findViewById(R.id.textViewBookId);
        TextView textViewBranchId = convertView.findViewById(R.id.textViewBranchId);
        TextView textViewAccessNo = convertView.findViewById(R.id.textViewAccessNo);

        if (bookCopy != null) {
            textViewBookId.setText(bookCopy.getBookId());
            textViewBranchId.setText(bookCopy.getBranchId());
            textViewAccessNo.setText(bookCopy.getAccessNo());
        }

        return convertView;
    }
}