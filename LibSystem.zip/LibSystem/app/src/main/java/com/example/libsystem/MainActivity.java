package com.example.libsystem;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

        import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btnManageBooks;
    private Button btnManagePublishers;
    private Button btnManageMembers;
    private Button btnManageBranches;
    private Button btnManageBookAuthors;
    private Button btnManageBookCopies;
    private Button btnManageBookLoans;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnManageBooks = findViewById(R.id.btn_manage_books);
        btnManagePublishers = findViewById(R.id.btn_manage_publishers);
        btnManageMembers = findViewById(R.id.btn_manage_members);
        btnManageBranches = findViewById(R.id.btn_manage_branches);
        btnManageBookCopies = findViewById(R.id.btn_manage_book_copies);
        btnManageBookLoans = findViewById(R.id.btn_manage_book_loans);
        btnManageBookAuthors = findViewById(R.id.btn_manage_book_authors);


        btnManageBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManageBooksActivity.class);
                startActivity(intent);
            }
        });

        btnManagePublishers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManagePublishersActivity.class);
                startActivity(intent);
            }
        });

        btnManageMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManageMembersActivity.class);
                startActivity(intent);
            }
        });

        btnManageBranches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManageBranchesActivity.class);
                startActivity(intent);
            }
        });

        btnManageBookAuthors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManageBookAuthorsActivity.class);
                startActivity(intent);
            }
        });

        btnManageBookCopies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManageBookCopiesActivity.class);
                startActivity(intent);
            }
        });

        btnManageBookLoans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManageBookLoansActivity.class);
                startActivity(intent);
            }
        });

    }
}



