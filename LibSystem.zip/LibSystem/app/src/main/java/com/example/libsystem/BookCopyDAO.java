package com.example.libsystem;

        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

public class BookCopyDAO {
    private SQLiteDatabase db;

    public BookCopyDAO(Context context) {
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertBookCopy(String bookId, String branchId, String accessNo) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("BRANCH_ID", branchId);
        values.put("ACCESS_NO", accessNo);
        return db.insert("Book_Copy", null, values);
    }

    public int updateBookCopy(String bookId, String branchId, String accessNo) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("BRANCH_ID", branchId);
        return db.update("Book_Copy", values, "ACCESS_NO = ? AND BRANCH_ID = ?", new String[]{accessNo, branchId});
    }

    public int deleteBookCopy(String accessNo, String branchId) {
        return db.delete("Book_Copy", "ACCESS_NO = ? AND BRANCH_ID = ?", new String[]{accessNo, branchId});
    }

    public Cursor getBookCopy(String accessNo, String branchId) {
        return db.query("Book_Copy", null, "ACCESS_NO = ? AND BRANCH_ID = ?", new String[]{accessNo, branchId}, null, null, null);
    }

    public Cursor getAllBookCopies() {
        return db.query("Book_Copy", null, null, null, null, null, "ACCESS_NO ASC");
    }
}