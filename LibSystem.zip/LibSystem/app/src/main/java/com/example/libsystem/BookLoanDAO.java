package com.example.libsystem;

        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.SQLException;
        import android.database.sqlite.SQLiteDatabase;

public class BookLoanDAO {
    private SQLiteDatabase db;
    private Context context;

    public BookLoanDAO(Context context) {
        this.context = context;
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }


    public void open() throws SQLException {
        db = new LibraryDatabaseHelper(context).getWritableDatabase();
    }


    public void close() {
        db.close();
    }

    public long insertBookLoan(String accessNo, String branchId, String cardNo,
                               String dateOut, String dateDue, String dateReturned) {
        ContentValues values = new ContentValues();
        values.put("ACCESS_NO", accessNo);
        values.put("BRANCH_ID", branchId);
        values.put("CARD_NO", cardNo);
        values.put("DATE_OUT", dateOut);
        values.put("DATE_DUE", dateDue);
        values.put("DATE_RETURNED", dateReturned);

        return db.insert("Book_Loan", null, values);
    }


    public int updateBookLoan(String accessNo, String branchId,
                              String cardNo, String dateOut, String dateDue,
                              String dateReturned) {
        ContentValues values = new ContentValues();
        values.put("DATE_DUE", dateDue);
        values.put("DATE_RETURNED", dateReturned);

        String whereClause = "ACCESS_NO = ? AND BRANCH_ID = ? AND CARD_NO = ? AND DATE_OUT = ?";
        String[] whereArgs = new String[]{accessNo, branchId, cardNo, dateOut};

        return db.update("Book_Loan", values, whereClause, whereArgs);
    }


    public int deleteBookLoan(String accessNo, String branchId,
                              String cardNo, String dateOut) {
        String whereClause = "ACCESS_NO = ? AND BRANCH_ID = ? AND CARD_NO = ? AND DATE_OUT = ?";
        String[] whereArgs = new String[]{accessNo, branchId, cardNo, dateOut};

        return db.delete("Book_Loan", whereClause, whereArgs);
    }


    public Cursor getBookLoan(String accessNo, String branchId,
                              String cardNo, String dateOut) {
        String whereClause = "ACCESS_NO = ? AND BRANCH_ID = ? AND CARD_NO = ? AND DATE_OUT = ?";
        String[] whereArgs = new String[]{accessNo, branchId, cardNo, dateOut};

        return db.query("Book_Loan", null, whereClause, whereArgs, null, null, null);
    }


    public Cursor getAllBookLoans() {
        return db.query("Book_Loan", null, null, null, null, null, "DATE_OUT ASC");
    }
}