package com.example.libsystem;


        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

public class BranchDAO {
    private SQLiteDatabase db;

    public BranchDAO(Context context) {
        LibraryDatabaseHelper dbHelper = new LibraryDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertBranch(String branchId, String branchName, String address) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", branchId);
        values.put("BRANCH_NAME", branchName);
        values.put("ADDRESS", address);
        return db.insert("Branch", null, values);
    }

    public int updateBranch(String branchId, String branchName, String address) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_NAME", branchName);
        values.put("ADDRESS", address);
        return db.update("Branch", values, "BRANCH_ID = ?", new String[]{branchId});
    }

    public int deleteBranch(String branchId) {
        return db.delete("Branch", "BRANCH_ID = ?", new String[]{branchId});
    }

    public Cursor getBranch(String branchId) {
        return db.query("Branch", null, "BRANCH_ID = ?", new String[]{branchId}, null, null, null);
    }

    public Cursor getAllBranches() {
        return db.query("Branch", null, null, null, null, null, "BRANCH_NAME ASC");
    }
}