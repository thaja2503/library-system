package com.example.libsystem;

public class BookAuthor {
    private String bookId;
    private String authorName;


    public BookAuthor(String bookId, String authorName) {
        this.bookId = bookId;
        this.authorName = authorName;
    }


    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
}
