package com.example.libsystem;


        import android.content.DialogInterface;
        import android.os.Bundle;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

        import androidx.appcompat.app.AlertDialog;
        import androidx.appcompat.app.AppCompatActivity;

        import java.util.ArrayList;
        import java.util.List;

public class ManageBookCopiesActivity extends AppCompatActivity {
    private ListView listViewBookCopies;
    private List<BookCopy> bookCopiesList;
    private BookCopyDAO bookCopyDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book_copies);

        bookCopyDAO = new BookCopyDAO(this);
        bookCopiesList = new ArrayList<>();
        listViewBookCopies = findViewById(R.id.listViewBookCopies);

        loadBookCopies();

        Button btnAddBookCopy = findViewById(R.id.btnAddBookCopy);
        btnAddBookCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddBookCopyDialog();
            }
        });
    }

    private void loadBookCopies() {
        bookCopiesList.clear();
        Cursor cursor = bookCopyDAO.getAllBookCopies();

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        String bookId = cursor.getString(cursor.getColumnIndex("BOOK_ID"));
                        String branchId = cursor.getString(cursor.getColumnIndex("BRANCH_ID"));
                        String accessNo = cursor.getString(cursor.getColumnIndex("ACCESS_NO"));


                        bookCopiesList.add(new BookCopy(bookId, branchId, accessNo));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }

        BookCopyAdapter bookCopyAdapter = new BookCopyAdapter(this, R.layout.item_book_copy, bookCopiesList);
        listViewBookCopies.setAdapter(bookCopyAdapter);
    }

    private void showAddBookCopyDialog() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_book_copy, null);
        dialogBuilder.setView(dialogView);

        final EditText editTextBookId = dialogView.findViewById(R.id.editTextBookId);
        final EditText editTextBranchId = dialogView.findViewById(R.id.editTextBranchId);
        final EditText editTextAccessNo = dialogView.findViewById(R.id.editTextAccessNo);

        dialogBuilder.setTitle("Add Book Copy");
        dialogBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                String bookId = editTextBookId.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();
                String accessNo = editTextAccessNo.getText().toString().trim();


                if (!bookId.isEmpty() && !branchId.isEmpty() && !accessNo.isEmpty()) {
                    long result = bookCopyDAO.insertBookCopy(bookId, branchId, accessNo);
                    if (result != -1) {
                        Toast.makeText(ManageBookCopiesActivity.this, "Book Copy added successfully", Toast.LENGTH_SHORT).show();
                        loadBookCopies();
                    } else {
                        Toast.makeText(ManageBookCopiesActivity.this, "Failed to add Book Copy", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookCopiesActivity.this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialogBuilder.setNegativeButton("Cancel", null);

        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }
}