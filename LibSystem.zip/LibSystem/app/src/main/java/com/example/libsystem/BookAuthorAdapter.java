package com.example.libsystem;

        import android.content.Context;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ArrayAdapter;
        import android.widget.TextView;

        import java.util.List;

public class BookAuthorAdapter extends ArrayAdapter<BookAuthor> {
    private final int resource;
    private final LayoutInflater inflater;

    public BookAuthorAdapter(Context context, int resource, List<BookAuthor> bookAuthors) {
        super(context, resource, bookAuthors);
        this.resource = resource;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(resource, parent, false);
        }

        BookAuthor bookAuthor = getItem(position);

        TextView textViewBookId = convertView.findViewById(R.id.textViewBookId);
        TextView textViewAuthorName = convertView.findViewById(R.id.textViewAuthorName);

        if (bookAuthor != null) {
            textViewBookId.setText(bookAuthor.getBookId());
            textViewAuthorName.setText(bookAuthor.getAuthorName());
        }

        return convertView;
    }
}